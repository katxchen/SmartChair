from NormalEq import *
from AccuracyTest import *
import numpy as np

inputfile = "test1.csv"

## Table of the sample to test. 'data_num' in rows and 'poly_order' in columns

data_num_list = [5, 10, 15, 10 ,25]
poly_order_list = [1, 2, 3, 4, 5]

min_MSE = 100
min_condition = [data_num_list[0], poly_order_list[0]]

for data_num in data_num_list:
	for poly_order in poly_order_list:
		MSE = Accuracytest(inputfile, data_num, poly_order)
		if(MSE <= min_MSE):
			min_MSE = MSE
			min_condition = [data_num, poly_order]
print("Min MSE = ", min_MSE, ", Min Condition = ", min_condition)