from NormalEq import *
import numpy as np

def Accuracytest(inputfile, data_num, poly_order):

	with open (inputfile) as file:
		rawlist = list(csv.reader(file))
	raw_data = np.array(rawlist, dtype=float)

	error_list = []

	for i in range(1000):

		data, test_data = data_making(raw_data, data_num)
		try:
			N = data_num
			N_p = poly_order
			start_time = time.clock()
			p = compute_lstsq(data, N_p)

		except ValueError as e:
			raise (error)

		else:
	        # Plot result
			x = np.linspace(min(data[:,0]), max(data[:,0]), 400)
			P, T, pro_time, pred_error = prediction(data, test_data, x, p, N, start_time)

			error_list.append(pred_error)

	error_list = np.array(error_list)
	MSE = sum(error_list**2)/len(error_list)
	print("Data No. = ", data_num, "Poly Order = ",poly_order ,  "MSE = ",MSE)
	return MSE

# # A python-isim. Basically if the file is being run execute the main() function.
if __name__ == "__main__":
    inputfile = sys.argv[1]
    data_num = int(sys.argv[2])
    poly_order = int(sys.argv[3])

    Accuracytest(inputfile, data_num, poly_order)
