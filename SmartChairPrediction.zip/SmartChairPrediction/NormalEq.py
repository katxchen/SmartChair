import numpy as np
import matplotlib.pyplot as plt
import sys
import csv
import time
import random

def compute_lstsq(data, n):
    
    if(data.shape[0] < n):
        print("Insufficient data points!")
    else:
        A = np.zeros((data.shape[0], n + 1))
        for i in range(n + 1):
            A[:,i] = data[:,0]**i
            
        p = np.dot(np.dot(np.linalg.inv(np.dot(A.T, A)),A.T),data[:,1])
    return p

def prediction(data, test_data, x, p, N, start_time):
	P = np.zeros(400)
	T = np.zeros(test_data.shape[0])
	for n in range(p.shape[0]):
		P += p[n] * x ** n
		T += p[n] * test_data[:,0] ** n
	end_time = time.clock()
	processing_time = end_time - start_time
	prediction_error = T - test_data[:,1]
	# print('Processing Time = ', processing_time)
	# print('Prediction Error = ', prediction_error[0])

	return P, T, processing_time, prediction_error

def plot_lstsq(data, test_data, P, T, x, p, N):#data, test_data, x, p, N, start_time):
    fig = plt.figure()
    axes = fig.add_subplot(1, 1, 1)
    axes.plot(data[:, 0], data[:, 1], 'ko', label='data')
    axes.plot(x, P, 'r', label='interpolant')
    axes.plot(test_data[:,0], T, 'o', label = 'prediction' )
    axes.plot(test_data[:,0], test_data[:,1] ,'o',label = 'real value')
    axes.set_title("Interpolant of order %s for %s data points" % (p.shape[0]-1, N))
    axes.set_xlabel("$x$")
    axes.set_ylabel("$P(x)$ and data")
    axes.legend()

def data_making(raw_data, data_num):

    start = random.randint(0,400)
    # start = 300
    end = start + data_num
    pred_num = 1

    data = raw_data[start:end, 0:2]
    test_data = raw_data[end:end+pred_num, 0:2]

    start_time = data[0,0]

    data = data - np.hstack(( np.ones((data_num,1))*start_time, np.zeros((data_num,1)) ))
    test_data = test_data - np.hstack(( np.ones((pred_num,1))*start_time, np.zeros((pred_num,1)) ))

    return data, test_data

def main():
    data, test_data = data_making(raw_data, data_num)
    try:
        N = data_num
        N_p = poly_order
        start_time = time.clock()
        p = compute_lstsq(data, N_p)
        # print(test_data)

    except ValueError as e:
        raise (error)

    else:
        # Plot result
        x = np.linspace(min(data[:,0]), max(data[:,0]), 400)
        P, T, pro_time, pred_error = prediction(data, test_data, x, p, N, start_time)
        print(pro_time)
        print(pred_error)
        plot_lstsq(data, test_data, P, T, x, p, N)

        plt.show()

# # A python-isim. Basically if the file is being run execute the main() function.
if __name__ == "__main__":
    inputfile = sys.argv[1]
    data_num = int(sys.argv[2])
    poly_order = int(sys.argv[3])
    
    with open (inputfile) as file:
        rawlist = list(csv.reader(file))
    raw_data = np.array(rawlist, dtype=float)

    main()
