import numpy as np
import matplotlib.pyplot as plt
import sys
import csv
import time

def Gradient():
	return 0

def ComputeCost(X, y, theta):

	m = len(y)
	J = 0

	J = np.dot( (X.dot(theta)-y).T, (X.dot(theta)-y) ) /2/m
	#print(J)

	return J

# def GD(data, n):

# 	alpha = 0.01
# 	theta = np.zeros((n+1, 1))
# 	E = np.zeros_like(theta)
# 	y = data[:,1].reshape((data.shape[0],1))
# 	m = len(y)

# 	if(m < n):
# 		print("Insufficient data points!")
# 		return theta
# 	else:
# 		X = np.zeros((m, n+1))
# 		for i in range(n + 1):
# 			X[:,i] = data[:,0]**i

# 	# print(X[:,1].T.shape)
# 	# print(X.dot(theta) - y)

# 	for i in range(50):
# 		ComputeCost(X, y, theta)
# 		for j in range(n+1):
# 			E[j] = X[:,j].T.dot((X.dot(theta) - y))
# 		theta -= alpha * E / m
# 			# print(E)
# 	return theta

def GD(x, y, theta_init, step=0.001, maxsteps=0, precision=0.001, ):
    costs = []
    m = y.size # number of data points
    theta = theta_init
    history = [] # to store all thetas
    preds = []
    counter = 0
    oldcost = 0
    pred = np.dot(x, theta)
    error = pred - y 
    currentcost = np.sum(error ** 2) / (2 * m)
    preds.append(pred)
    costs.append(currentcost)
    history.append(theta)
    counter+=1
    while abs(currentcost - oldcost) > precision:
        oldcost=currentcost
        gradient = x.T.dot(error)/m 
        theta = theta - step * gradient  # update
        history.append(theta)
        
        pred = np.dot(x, theta)
        error = pred - y 
        currentcost = np.sum(error ** 2) / (2 * m)
        costs.append(currentcost)
        
        if counter % 25 == 0: preds.append(pred)
        counter+=1
        if maxsteps:
            if counter == maxsteps:
                break
        
    return history, costs, preds, counter, theta

def plot_lstsq(data, x, p, N):
    P = np.zeros(400)
    for n in range(p.shape[0]):
        P += p[n] * x ** n
    fig = plt.figure()
    axes = fig.add_subplot(1, 1, 1)
    axes.plot(data[:, 0], data[:, 1], 'ko', label='data')
    axes.plot(x, P, 'r', label='interpolant')
    axes.set_title("Interpolant of order %s for %s data points" % (p.shape[0], N))
    axes.set_xlabel("$x$")
    axes.set_ylabel("$P(x)$ and data")
    axes.legend()

def data_making(raw_data, data_num):
    start = 300
    data = raw_data[start:start + data_num, 0:2]
    data = data - np.hstack(( np.ones((data_num,1))*data[0,0], np.zeros((data_num,1)) ))
    return data * 10

def main():
    data = data_making(raw_data, data_num)
    y = data[:,1].reshape((data.shape[0],1))
    X = np.zeros((m, n+1))
	
	for i in range(n + 1):
		X[:,i] = data[:,0]**i

    # N = data_num
    # N_p = poly_order
    # start_time = time.clock()
    # p = GD(data, N_p)

    try:
		N = data_num
		N_p = poly_order
		theta = np.zeros((n+1, 1))
		start_time = time.clock()
		history, costs, preds, counter, theta = GD(X, y, theta)
		end_time = time.clock()
		print(end_time - start_time)

    except ValueError as e:
        raise (error)

    else:
        # Plot result
        x = np.linspace(min(data[:,0]), max(data[:,0]), 400)
        plot_lstsq(data, x, theta, N)
        plt.show()

# # A python-isim. Basically if the file is being run execute the main() function.
if __name__ == "__main__":
    inputfile = sys.argv[1]
    data_num = int(sys.argv[2])
    poly_order = int(sys.argv[3])
    
    with open (inputfile) as file:
        rawlist = list(csv.reader(file))
    raw_data = np.array(rawlist, dtype=float)

    main()