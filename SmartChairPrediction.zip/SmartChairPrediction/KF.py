# Function 'kalman_filter' that implements a multi-dimensional Kalman Filter



import numpy as np
import matplotlib.pyplot as plt
import sys
import csv
import random
from math import *


class matrix:
    
    # implements basic operations of a matrix class
    
    def __init__(self, value):
        self.value = value
        self.dimx = len(value)
        self.dimy = len(value[0])
        if value == [[]]:
            self.dimx = 0
    
    def zero(self, dimx, dimy):
        # check if valid dimensions
        if dimx < 1 or dimy < 1:
            raise ValueError, "Invalid size of matrix"
        else:
            self.dimx = dimx
            self.dimy = dimy
            self.value = [[0 for row in range(dimy)] for col in range(dimx)]
    
    def identity(self, dim):
        # check if valid dimension
        if dim < 1:
            raise ValueError, "Invalid size of matrix"
        else:
            self.dimx = dim
            self.dimy = dim
            self.value = [[0 for row in range(dim)] for col in range(dim)]
            for i in range(dim):
                self.value[i][i] = 1
    
    def show(self):
        for i in range(self.dimx):
            print(self.value[i])
        print(' ')
    
    def __add__(self, other):
        # check if correct dimensions
        if self.dimx != other.dimx or self.dimy != other.dimy:
            raise ValueError, "Matrices must be of equal dimensions to add"
        else:
            # add if correct dimensions
            res = matrix([[]])
            res.zero(self.dimx, self.dimy)
            for i in range(self.dimx):
                for j in range(self.dimy):
                    res.value[i][j] = self.value[i][j] + other.value[i][j]
            return res
    
    def __sub__(self, other):
        # check if correct dimensions
        if self.dimx != other.dimx or self.dimy != other.dimy:
            raise ValueError, "Matrices must be of equal dimensions to subtract"
        else:
            # subtract if correct dimensions
            res = matrix([[]])
            res.zero(self.dimx, self.dimy)
            for i in range(self.dimx):
                for j in range(self.dimy):
                    res.value[i][j] = self.value[i][j] - other.value[i][j]
            return res
    
    def __mul__(self, other):
        # check if correct dimensions
        if self.dimy != other.dimx:
            raise ValueError, "Matrices must be m*n and n*p to multiply"
        else:
            # multiply if correct dimensions
            res = matrix([[]])
            res.zero(self.dimx, other.dimy)
            for i in range(self.dimx):
                for j in range(other.dimy):
                    for k in range(self.dimy):
                        res.value[i][j] += self.value[i][k] * other.value[k][j]
            return res
    
    def transpose(self):
        # compute transpose
        res = matrix([[]])
        res.zero(self.dimy, self.dimx)
        for i in range(self.dimx):
            for j in range(self.dimy):
                res.value[j][i] = self.value[i][j]
        return res
    
    # Thanks to Ernesto P. Adorio for use of Cholesky and CholeskyInverse functions
    
    def Cholesky(self, ztol=1.0e-5):
        # Computes the upper triangular Cholesky factorization of
        # a positive definite matrix.
        res = matrix([[]])
        res.zero(self.dimx, self.dimx)
        
        for i in range(self.dimx):
            S = sum([(res.value[k][i])**2 for k in range(i)])
            d = self.value[i][i] - S
            if abs(d) < ztol:
                res.value[i][i] = 0.0
            else:
                if d < 0.0:
                    raise ValueError, "Matrix not positive-definite"
                res.value[i][i] = sqrt(d)
            for j in range(i+1, self.dimx):
                S = sum([res.value[k][i] * res.value[k][j] for k in range(self.dimx)])
                if abs(S) < ztol:
                    S = 0.0
                try:
                   res.value[i][j] = (self.value[i][j] - S)/res.value[i][i]
                except:
                   raise ValueError, "Zero diagonal"
        return res
    
    def CholeskyInverse(self):
        # Computes inverse of matrix given its Cholesky upper Triangular
        # decomposition of matrix.
        res = matrix([[]])
        res.zero(self.dimx, self.dimx)
        
        # Backward step for inverse.
        for j in reversed(range(self.dimx)):
            tjj = self.value[j][j]
            S = sum([self.value[j][k]*res.value[j][k] for k in range(j+1, self.dimx)])
            res.value[j][j] = 1.0/tjj**2 - S/tjj
            for i in reversed(range(j)):
                res.value[j][i] = res.value[i][j] = -sum([self.value[i][k]*res.value[k][j] for k in range(i+1, self.dimx)])/self.value[i][i]
        return res
    
    def inverse(self):
        aux = self.Cholesky()
        res = aux.CholeskyInverse()
        return res
    
    def __repr__(self):
        return repr(self.value)


########################################

# Implement the filter function below

def kalman_filter(x, P, Q, F, H, R, I, timestamp, measurements):

    x_pred = [] #History of x-state ([acceleration, Velocity, Position])
    x_pred.append(x) #Store the initial value
    accel_pred = [] #History of acceleration
    accel_pred.append(x.value[0][0]) #Store the initial value
    velo_pred = [] #History of velocity
    velo_pred.append(x.value[1][0]) #Store the initial value
    posi_pred = [] #History of position
    posi_pred.append(x.value[2][0]) #Store the initial value

    for n in range(len(measurements)-1):

        dt = timestamp[n+1] - timestamp[n]
        dt_2 = dt*dt
        dt_3 = dt_2*dt
        dt_4 = dt_3*dt
        dt_5 = dt_4*dt
        dt_6 = dt_5*dt

        #Update F Matrix
        F.value = [[1., 0., 0.], [dt, 1., 0.], [dt_2/2., 1, 1.]]

        #Update Q Matrix
        Nx = 0.1 #Prediction Noise in unit g/s
        Q.value = [[dt_2*Nx, dt_3/2.*Nx, dt_4/6.*Nx], [dt_3/2.*Nx, dt_4/4.*Nx, dt_5/12.*Nx], [dt_4/6.*Nx, dt_5/12.*Nx, dt_6/36*Nx]]

        # measurement update
        Z = matrix([[measurements[n+1]]])
        y = Z - H*x
        S = H*P*H.transpose() + R
        K = P*H.transpose()*S.inverse()
        x = x + ( K * y )
        P = ( I - K*H) * P

        # prediction
        x = F*x
        P = F*P*F.transpose() + Q

        #Store the result to history
        x_pred.append(x)
        accel_pred.append(x.value[0][0])
        velo_pred.append(x.value[1][0])
        posi_pred.append(x.value[2][0])
        
    return x_pred, accel_pred, velo_pred, posi_pred

############################################
### use the code below to test your filter!
############################################

#Function for plot
def plot_filtered(timestamp, measurements, accel_pred, velo_pred, posi_pred):
    fig = plt.figure()
    axes = fig.add_subplot(1, 1, 1)
    axes.plot(timestamp, measurements, 'ko', label='data')
    axes.plot(timestamp, accel_pred, 'r', label='Filtered Accel')
    axes.plot(timestamp, velo_pred, 'b', label='Pred velo')
    axes.plot(timestamp, posi_pred, 'g', label='Pred posi')
    axes.set_title("Filtered data" )
    axes.set_xlabel("$Time$")
    axes.set_ylabel("$Filtered value$ and measurements")
    axes.legend()

#Function for change the csv_data into timestamps and measurement values for certain num of data.
def data_making(raw_data, data_num):
    # start = random.randint(0,400)
    start = 0 #For this example I start from time zero.
    end = start + data_num #Extract the Nth number of data from start to end
    pred_num = 1

    data = raw_data[start:end, 0:2]
    test_data = raw_data[end:end+pred_num, 0:2]

    start_time = data[0,0]
    #Change time that time start from zero no matter where it start.
    data = data - np.hstack(( np.ones((data_num,1))*start_time, np.zeros((data_num,1)) )) 
    test_data = test_data - np.hstack(( np.ones((pred_num,1))*start_time, np.zeros((pred_num,1)) ))

    timestamp = data[:,0]
    measurements = data[:,1]

    return timestamp, measurements, test_data

def main():
    timestamp, measurements, test, data = data_making(raw_data, data_num)

    #Initial paramater
    x = matrix([[0.], [0.], [0.]]) # initial state (location, velocity and acceleration)
    P = matrix([[1000., 0., 0.], [0., 1000., 0.], [0., 0., 1000.]]) # initial uncertainty
    Q = matrix([[0., 0., 0.], [0., 0., 0.], [0., 0., 0.]]) # Prediction uncertainty
    F = matrix([[1., 0., 0.], [0.1, 1., 0.], [.1/2., 1, 1.]]) # Initial next state function
    H = matrix([[1., 0., 0.]]) # measurement function (Only measure acceleration by IMU)
    R = matrix([[50./1000000.]]) # measurement uncertainty (150ug/sqrt(Hz) from BNO055 datasheet)
    I = matrix([[1., 0., 0.], [0., 1., 0.], [0., 0., 1.]]) # identity matrix

    x_pred, accel_pred, velo_pred, posi_pred = kalman_filter(x, P, Q, F, H, R, I, timestamp, measurements)
    # print(accel_pred)
    # print(timestamp)

    plot_filtered(timestamp, measurements, accel_pred, velo_pred, posi_pred)

    plt.show()


# A python-isim. Basically if the file is being run execute the main() function.
if __name__ == "__main__":
    inputfile = sys.argv[1]
    data_num = int(sys.argv[2])
    
    with open (inputfile) as file:
        rawlist = list(csv.reader(file))
    raw_data = np.array(rawlist, dtype=float)

    main()
